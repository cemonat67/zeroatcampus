from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import time
import random
import datetime
import os
import tarfile
import requests
import glob

app = FastAPI()

# Config
N8N_BASE_URL = os.getenv("N8N_BASE_URL", "http://127.0.0.1:5678")
BACKUP_DIR = "runtime/backups"

# Enable CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Data Models ---

class SystemStatus(BaseModel):
    system_state: str  # OK, DEGRADED, HEALING
    brain: str
    agents: str
    backup: str
    cache: str
    last_incident: Optional[str] = None
    latency_ms: Optional[int] = None
    updated_at: Optional[str] = None
    backend_version: Optional[str] = None

class Workflow(BaseModel):
    name: str
    status: str
    last_run: str
    next_run: str

class OrchestratorStatus(BaseModel):
    ok: bool
    workflows: List[Workflow]
    queue: dict
    webhooks_last_ping: str

class Incident(BaseModel):
    ts: str
    type: str
    action: str
    result: str
    severity: str = "LOW"
    duration_ms: Optional[int] = None

class IncidentLog(BaseModel):
    incidents: List[Incident]

class BrainIntent(BaseModel):
    intent: str
    recommended_tab: str

class BackupResponse(BaseModel):
    ok: bool
    file: str
    size_bytes: int
    ts: str

class BackupStatus(BaseModel):
    last_ok_ts: Optional[str] = None
    last_file: Optional[str] = None
    size_bytes: Optional[int] = None
    age_seconds: Optional[int] = None

# --- State ---

state = {
    "system_status": "OK",
    "last_incident": None,
    "workflows": [
        {"name": "Incident Agent", "status": "Running", "last_run": "2m ago", "next_run": "in 3m"},
        {"name": "Evidence Agent", "status": "Running", "last_run": "5m ago", "next_run": "in 10m"},
        {"name": "Backup Agent", "status": "Idle", "last_run": "1h ago", "next_run": "in 5h"},
        {"name": "Forecast Refresh", "status": "Running", "last_run": "10m ago", "next_run": "in 50m"}
    ],
    "incidents": [],
    "last_backup": {
        "ts": None,
        "file": None,
        "size": 0
    }
}

# --- Endpoints ---

@app.get("/api/health")
def get_health():
    return {
        "ui": "OK",
        "api": "OK",
        "db": "OK",
        "n8n": "OK",
        "ts": int(time.time()),
        "status": state["system_status"]
    }

@app.get("/api/system/status")
def get_system_status():
    start_time = time.time()
    agents_status = "Running"
    if state["system_status"] != "OK":
        agents_status = "Degraded"
    
    latency = int((time.time() - start_time) * 1000) + random.randint(10, 50) # Simulate network + processing
    
    # Calculate backup status
    backup_text = "Today 04:00 AM"
    if state["last_backup"]["ts"]:
         # rough format "2m ago"
         diff = time.time() - datetime.datetime.fromisoformat(state["last_backup"]["ts"]).timestamp()
         if diff < 60:
             backup_text = "Just now"
         elif diff < 3600:
             backup_text = f"{int(diff/60)}m ago"
         else:
             backup_text = "Today"

    return {
        "system_state": state["system_status"],
        "brain": "Online",
        "agents": f"{agents_status} (4/4)",
        "backup": backup_text,
        "cache": "Ready",
        "last_incident": state["last_incident"],
        "latency_ms": latency,
        "updated_at": datetime.datetime.now().isoformat(),
        "backend_version": "v0.1.0"
    }

@app.get("/api/orchestrator/n8n/status")
def get_orchestrator_status():
    # Try to reach real n8n
    try:
        # Check n8n health (fake endpoint for demo logic or real if exists)
        # For this demo, we assume n8n is running if we can reach it, 
        # otherwise fallback to simulated state
        requests.get(f"{N8N_BASE_URL}/healthz", timeout=1) 
        
        # In a real scenario, we would fetch workflows from n8n API
        # For now, we simulate "Real" status if reachable
        return {
            "ok": True,
            "workflows": state["workflows"],
            "queue": {"pending": 0},
            "webhooks_last_ping": "Live"
        }
    except:
        # Fallback
        return {
            "ok": False,
            "workflows": state["workflows"],
            "queue": {"pending": random.randint(0, 5)},
            "webhooks_last_ping": "Offline (Seed)"
        }

@app.post("/api/orchestrator/n8n/run")
def run_workflow(payload: dict):
    # Demo-safe trigger
    wf_name = payload.get("workflow")
    return {"started": True, "run_id": f"exec_{int(time.time())}", "workflow": wf_name}

# --- Backup Endpoints ---

@app.post("/api/backup/run")
def run_backup():
    # Create backup
    ts = datetime.datetime.now().isoformat()
    filename = f"backup_{int(time.time())}.tar.gz"
    filepath = os.path.join(BACKUP_DIR, filename)
    
    # Create valid tar.gz of key files
    with tarfile.open(filepath, "w:gz") as tar:
        if os.path.exists("zero-campus.html"):
            tar.add("zero-campus.html")
        if os.path.exists("backend"):
            tar.add("backend")
            
    size = os.path.getsize(filepath)
    
    state["last_backup"] = {
        "ts": ts,
        "file": filename,
        "size": size
    }
    
    return {
        "ok": True,
        "file": filename,
        "size_bytes": size,
        "ts": ts
    }

@app.get("/api/backup/status")
def get_backup_status():
    lb = state["last_backup"]
    age = 0
    if lb["ts"]:
        age = int(time.time() - datetime.datetime.fromisoformat(lb["ts"]).timestamp())
        
    return {
        "last_ok_ts": lb["ts"],
        "last_file": lb["file"],
        "size_bytes": lb["size"],
        "age_seconds": age
    }
    
@app.post("/api/backup/verify")
def verify_backup():
    lb = state["last_backup"]
    if not lb["file"]:
        raise HTTPException(status_code=404, detail="No backup found")
        
    filepath = os.path.join(BACKUP_DIR, lb["file"])
    if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
        return {"ok": True}
    else:
        raise HTTPException(status_code=500, detail="Backup file missing or empty")

@app.post("/api/simulate/fail")
def simulate_fail():
    state["system_status"] = "DEGRADED"
    state["last_incident"] = "API Latency Spike detected"
    # Update agent status for visual impact
    state["workflows"][0]["status"] = "Retrying..."
    return {"status": "System set to DEGRADED"}

@app.post("/api/selfheal/run")
def self_heal():
    start = time.time()
    time.sleep(1) # Simulate work
    state["system_status"] = "HEALING"
    time.sleep(1)
    state["system_status"] = "OK"
    
    duration = int((time.time() - start) * 1000)
    
    # Log incident
    incident = {
        "ts": time.strftime("%H:%M:%S"),
        "type": "Latency Spike",
        "action": "Auto-Scale + Cache Flush",
        "result": "Resolved",
        "severity": "HIGH",
        "duration_ms": duration
    }
    state["incidents"].insert(0, incident)
    if len(state["incidents"]) > 5:
        state["incidents"].pop()
        
    state["last_incident"] = f"Resolved: {incident['type']}"
    
    # Restore agents
    state["workflows"][0]["status"] = "Running"
    
    return {"status": "System Healed", "incident": incident}

@app.get("/api/incidents/recent")
def get_incidents():
    return {"incidents": state["incidents"]}

@app.post("/api/brain/decide")
def brain_decide(context: dict):
    role = context.get("role", "Admin")
    
    if role == "Dean":
        return {"intent": "Strategic Overview", "recommended_tab": "executive"}
    elif role == "Facility":
        return {"intent": "Operational Control", "recommended_tab": "scopes"} # Assuming scopes is close to ops
    elif role == "Sustainability":
        return {"intent": "Compliance & Reporting", "recommended_tab": "reporting"}
    else:
        return {"intent": "General Overview", "recommended_tab": "overview"}

# Chart Data Endpoints (Seed Data)
@app.get("/api/charts/energy")
def get_energy_chart():
    # 30 days data
    actual = [random.randint(400, 600) for _ in range(30)]
    forecast = [random.randint(400, 600) for _ in range(30)]
    return {"actual": actual, "forecast": forecast}

@app.get("/api/charts/water")
def get_water_chart():
    actual = [random.randint(50, 100) for _ in range(30)]
    forecast = [random.randint(50, 100) for _ in range(30)]
    return {"actual": actual, "forecast": forecast}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8095)
